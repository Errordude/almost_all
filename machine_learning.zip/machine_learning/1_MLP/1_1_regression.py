from keras.datasets import boston_housing
from keras.models import Sequential
from keras.layers import Activation, Dense
from keras import optimizers

(X_train, y_train), (X_test, y_test) = boston_housing.load_data()

model = Sequential()

# two hidden layers 
model.add(Dense(12, input_shape = (13,))) 
model.add(Activation('sigmoid'))
model.add(Dense(11))                         
model.add(Activation('sigmoid'))
model.add(Dense(10))                         
only output dimension should be designated
model.add(Activation('sigmoid'))
model.add(Dense(1))                         


sgd = optimizers.SGD(lr = 0.01)

model.compile(optimizer = sgd, loss = 'mean_squared_error', metrics = ['mse']) 
model.fit(X_train, y_train, batch_size = 50, epochs = 100, verbose = 1)

results = model.evaluate(X_test, y_test)

print('Loss: ', results[0])
print('Mse: ', results[1])