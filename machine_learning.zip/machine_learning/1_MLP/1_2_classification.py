from keras.datasets import boston_housing
from keras.models import Sequential
from keras.layers import Activation, Dense
from keras import optimizers
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

whole_data = load_breast_cancer()

X_data = whole_data.data
y_data = whole_data.target

X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, test_size = 0.3, random_state = 7) 

model = Sequential()

# Keras model with two hidden layer with 10 neurons each 
model.add(Dense(20, input_shape = (30,))) 
model.add(Activation('sigmoid'))
model.add(Dense(12))                 
model.add(Activation('sigmoid'))
model.add(Dense(14))                        
model.add(Activation('sigmoid'))
model.add(Dense(1))                          
model.add(Activation('sigmoid'))


sgd = optimizers.SGD(lr = 0.01)    
# stochastic gradient descent

model.compile(optimizer = sgd, loss = 'binary_crossentropy', metrics = ['accuracy'])
model.fit(X_train, y_train, batch_size = 50, epochs = 100, verbose = 1)

results = model.evaluate(X_test, y_test)

print('Loss: ', results[0])
print('Accuracy: ', results[1])